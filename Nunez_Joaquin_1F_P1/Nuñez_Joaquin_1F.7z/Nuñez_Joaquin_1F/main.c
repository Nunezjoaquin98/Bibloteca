#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "Clientes Juegos.h"
#define TAMCLIENTES 100
#define TAMJUEGOS 5
int main()
{
 //declaro las variables
 char salir = 'n';
 eClientes clientes[TAMCLIENTES];
 eJuego juegos[TAMJUEGOS];

 initClientes(clientes,TAMCLIENTES); ////se inicializa todos los isEmpty en 1 indicando que estan vacios
 hardcodeoClientes(clientes);
 hardcodeoJuegos(juegos);

    do
    {
        switch(menu())
        {
            case 1://clientes

                switch(menuClientes())
                {
                    case 1:
                        addCliente(clientes,TAMCLIENTES); //ALTA CLIENTE
                        break;
                    case 2:
                        modifyCliente(clientes,TAMCLIENTES); // MODIFICAR CLIENTE
                        break;
                    case 3:
                        removeCliente(clientes,TAMCLIENTES,0); //BAJA CLIENTE
                        break;
                    case 4:
                        sortClientes(clientes,TAMCLIENTES); // LISTAR CLIENTES
                        showClientes(clientes,TAMCLIENTES);
                        system("pause");
                        break;
                }
            break;

            case 2: //juegos
                sortJuegos(juegos,TAMJUEGOS);
                showJuegos(juegos,TAMJUEGOS);
                system("pause");
                break;

            case 3: //alquileres
            do
            {
                switch(menuPrestamos())
                {
                case 1:
                    addPrestamo(sociosBiblioteca,tamSocios,exitos,tamLibros,prestamos,tamPrestamos,escritores,tamAutores);
                    printf("\n\n");
                    system("pause");
                    break;
                case 2:
                    system("cls");
                    mostrarPrestamos(prestamos,tamPrestamos,exitos,tamLibros,sociosBiblioteca,tamSocios);
                    printf("\n\n");
                    system("pause");
                    break;
                case 3:
                    salirPrestamo = 's';
                    printf("\n\nVolviendo al menu principal...\n\n");
                    system("pause");
                    break;
                }
            }
            while(salirPrestamo == 'n');
            break;

        }
    }while(salir == 'n');

    return 0;
}
