typedef struct
{
    int dia;
    int mes;
    int anio;
}eFecha;


void ingresarDia(char auxDia[]);
/** \brief ingresa un dia valido del 1 al 31
 *
 *
 *
 */


void ingresarMes(char auxMes[]);
/** \brief ingresa un mes valido del 1 al 12
 *
 *
 *
 */


void ingresarAnio(char auxAnio[]);
/** \brief ingresa un anio
 *
 * \return
 *
 */

