#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "Clientes Juegos.h"
#include "alquileres.h"
#include "fecha.h"

int initAlquileres(eAlquileres list[], int len)
{
    int ret = 0;

    if(list != NULL && len > 0)
    {

        for(int i=0; i < len; i++)
        {

            list[i].isEmpty = 1;
        }
    }
    else
    {
        ret = -1;
    }

    return ret;

}


int searchEmptyAlquiler(eAlquileres list[],int len)
{
    int index = -1;
    for(int i=1; i<len ; i++)
    {
        if( list[i].isEmpty == 1)
        {
            index = i ;
            break;
        }
    }
    return index ;
}

int addAlquiler(eClientes listClientes[],int tamClie,eJuego listJuego[],int tamJuego,eAlquileres listAlq[],int tamAlq)
{
    int ret,index,indexJuego,indexCliente;
    eAlquileres newAlquiler;
    char auxJuego[3];
    char auxCliente[4];
    char anio[5];
    char mes[5];
    char dia[5];


    if(listAlq != NULL && tamAlq > 0)
    {
        system("cls");
        fflush(stdin);
        index = searchEmptyAlquiler(listAlq,tamAlq);
        printf("\t\t***ALTA DE ALQUILER***");
        if(index == -1)
        {
            printf("\nNo hay lugar en el sistema. \n") ;
            ret = -1 ;
            system("pause");

        }
        else
        {


            printf("\nNuevo alquiler, CODIGO numero %d. \n\n",index) ;

            // SE LE HACE SELECCIONAR UN JUEGO AL USUARIO
            do
            {
                printf("\nSeleccionar el juego alquiladp:\n");
                showJuegos(listJuego,tamJuego);
                while(!function_getStringNumeros("\n\nIngrese el numero de codigo del JUEGO: ",auxJuego))
                {
                    printf("Error el codigo debe tener solo numeros.\n\n");
                    system("pause");
                }
                indexJuego = findJuego(listJuego,tamJuego,atoi(auxJuego));
                if(indexJuego == -1)
                {
                    printf("\n***ERROR*** El codigo del juego es incorrecto");
                }
                else
                {
                    system("cls");
                    printf("\n\nEl juego seleccionado es:\n");
                    printf("\n\n\nCODIGO\tDESCRIPCION\tIMPORTE\n\n");
                    showJuego(listJuego[indexJuego]);
                }

            }
            while(indexJuego == -1);

            // carga de Cliente
            printf("\nSeleccionar el cliente que realizo el alquiler:\n");
            showClientes(listClientes,tamClie);
            do
            {
                while(!function_getStringNumeros("\nIngrese el numero de codigo del cliente: ",auxCliente))
                {
                    printf("\nError el codigo debe tener solo numeros.\n\n");
                    system("pause");
                }
                indexCliente = findCliente(listClientes,tamClie,atoi(auxCliente));
                if(indexCliente == -1)
                {
                    printf("\n***ERROR*** Codigo incorrecto\n");
                    system("pause");
                }
                else
                {
                    printf("\nEl cliente seleccionado es:\n");
                    printf("\n\nCODIGO\tAPELLIDO NOMBRE\tSEXO\tDOMICILIO\tTELEFONO\n\n");
                    showCliente(listClientes[indexCliente]);
                }

            }
            while(indexCliente == -1);

            //carga de la fecha
            printf("\n\nIngresar fecha del alquiler:\n");
            ingresarDia(dia);
            ingresarMes(mes);
            ingresarAnio(anio);

            //se copian todos los datos al nuevo Alquiler
            newAlquiler.codigoDeAlquiler = index;
            newAlquiler.codigoJuego = listJuego[indexJuego];
            newAlquiler.codigoCliente = listClientes[indexCliente];
            newAlquiler.fechaDeAlquiler.dia = atoi(dia);
            newAlquiler.fechaDeAlquiler.mes = atoi(mes);
            newAlquiler.fechaDeAlquiler.anio = atoi(anio);
            newAlquiler.isEmpty = 0;
            listAlq[index] = newAlquiler;
            system("cls");
            mostrarAlquiler(listAlq[index],tamAlq,listJuego,tamJuego,listClientes,tamClie);
            printf("\n\n");


        }
    }
    else
    {
        ret = -1 ;
    }
    return ret;
}

void mostrarAlquiler(eAlquileres listAlq,int lenAlq,eJuego listJuego[],int lenJuegos,eClientes listCliente[],int lenClien)
{
    int indexJuego,indexCliente;

    printf("\t\t-ALQUILER-\n\nCodigo del alquiler: %d\nFecha del prestamo: %d/%d/%d\n\n",listAlq.codigoDeAlquiler,listAlq.fechaDeAlquiler.dia,listAlq.fechaDeAlquiler.mes,listAlq.fechaDeAlquiler.anio);

    indexJuego = findJuego(listJuego,lenJuegos,listAlq.codigoJuego.codigoDelJuego); // se busca la posicion del juego

    printf("\t\t Juego \nDescripcion: %s\nImporte: $%0.2f \n\n",listJuego[indexJuego].descripcion,listJuego[indexJuego].importeDelJuego);

    indexCliente = findCliente(listCliente,lenClien,listAlq.codigoCliente.codigoDeCliente);
    printf("\t\t Cliente \nApellido y nombre: %s %s\nCodigo de socio: %d",listCliente[indexCliente].apellidoCliente,listCliente[indexCliente].nombreCliente,listCliente[indexCliente].codigoDeCliente);

}
